#include<unistd.h>

char rot(char c)
{

        if(c >= 'a' && c <= 'm' ||c >= 'A' && c <= 'M' )
                return c + 13;
        else if (c >= 'n' && c <= 'z' ||c >= 'N' && c <= 'Z' )
                  return  c - 13;
        else
       return c;
 }



int main(int ac, char **av)
{

    if(ac == 2)
    {
        for(int i  = 0; av[1][i];i++){
            char r = rot(av[1][i]);
            write(1,&r,1);
        }
        
    }
    write(1,"\n",1);
    return 0;

}