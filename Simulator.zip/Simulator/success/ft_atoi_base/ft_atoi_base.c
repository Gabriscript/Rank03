
int is_valid(char c)
{
    return(c >= 'a' && c <= 'f' ||c >= 'A' && c <= 'F' ||c >= '0' && c <= '9' );

}

int	ft_atoi_base(const char *str, int str_base)
{
    int i = 0;
    int sign = 1;
    int res = 0;

    while(str[i])
    {   
        while(str[i] <= 32)
            i++;

        if(str[i] == '+' || str[i] == '-')
            {
                if(str[i] == '-')
                    sign = -sign;
                i++;
            }
            while(is_valid(str[i]))
            {

                res = res * str_base;
                
                if(str[i] >= '0' && str[i] <= '9')
                    res += str[i]- '0';
                else if (str[i] >= 'A' && str[i] <= 'F')
                     res += str[i] - 'A' + 10;
                else if(str[i] >= 'a' && str[i] <= 'f')
                     res += str[i] - 'a' + 10;
                i++;             

            }
            if(!is_valid(str[i]))
                break;
    }    
    return res * sign;
}