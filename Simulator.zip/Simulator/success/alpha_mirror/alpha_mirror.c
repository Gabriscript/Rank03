#include<unistd.h>
char mirror(char c)
{
        if ( c >= 'a' && c <= 'z')
            return 219 - c;
        else if ( c >= 'A' && c <= 'Z')
        return  155 - c;
        else 
        return c;
}

int main(int ac, char **av)
{

    if(ac == 2)
    {
        for(int i  = 0; av[1][i];i++){
            char r = mirror(av[1][i]);
            write(1,&r,1);
        }
        
    }
    write(1,"\n",1);
    return 0;

}